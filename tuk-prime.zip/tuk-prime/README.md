# TUK Prime — Setup & Publishing Guide

## What's fixed / added in this version
- Nav bug: "Courses" tab no longer shows a stale faculty before you've picked one.
- Every course now has **2 quiz questions** (up from 1), each with an explanation after you answer.
- **Search bar** on the Faculties screen to filter by course name or topic.
- **Progress tracking** (saved in the browser via localStorage): studied topics get a ✓ badge, and the home screen shows a progress bar.
- **Study Assistant** screen: a keyword search across every note in the app — see the "About the Study Assistant" note below.
- Cleaned up visual design (navy/gold academic theme, consistent card system, real button states) instead of the neon-green placeholder button.
- Real Google AdSense `<ins>` ad units wired in (4 slots), replacing the fake black "AD" placeholder boxes.

## Full official TUK course catalogue (latest update)
The app now covers **all 77 Bachelor's degree programmes** currently listed on TUK's own admissions portal (intake.tukenya.ac.ke), organized under the university's **actual 3 faculties and their real departments**, pulled directly from tukenya.ac.ke and the intake portal rather than invented:
- **Faculty of Engineering & the Built Environment (FEBE)** — 20 programmes across Architecture, Chemical & Biosystems, Civil & Resource, Construction & Property, Electrical & Electronics, Mechanical & Aerospace, and Surveying & Spatial Sciences.
- **Faculty of Social Sciences and Technology (FSST)** — 31 programmes across Business & Management, Creative Arts & Media, Hospitality & Human Ecology, Information Science/Language/Communication, and Liberal Development & International Studies.
- **Faculty of Applied Sciences and Technology (FAST)** — 26 programmes across Biological & Life Sciences, Computing & IT, Chemistry & Materials Science, Health & Biomedical Sciences, Mathematics & Statistics, and Physics/Earth/Environmental Sciences.

Every one of the 77 has its own notes and a 2-question quiz — 154 questions total. **Diplomas, certificates, Master's and PhD programmes are intentionally not included** — that's a separate, much larger catalogue (60+ diplomas, 64 Master's, 51 PhDs) — let me know if you want those added as a further pass.

Faculty and department names, and the full programme list, were pulled from TUK's official site and admissions portal at the time of writing. Universities update their programme offerings periodically, so it's worth spot-checking the current list at intake.tukenya.ac.ke before relying on this for official advising.

## About the Study Assistant (read this before calling it "AI")
There is no real AI model running inside this file. Embedding a genuine language model would require sending your users' questions to a server with a secret API key — and any key placed inside a downloadable HTML file is visible to anyone who views the page source, so it would be stolen and abused within hours. That's not a limitation I can safely code around client-side.

What's built instead is an honest, useful substitute: a keyword search across all the notes already in the app, so a student typing "explain CSTR" gets pointed straight to the matching topic. The app is upfront about this in-app (see the disclaimer text on the Assistant screen) — please don't remove that disclaimer or market this feature as "AI-powered," since it isn't.

If you do want real AI Q&A later, the only safe way is:
1. Build a small backend (e.g. a free-tier Cloudflare Worker or Vercel function) that holds your API key server-side.
2. Have the app call your backend, and your backend calls the AI provider.
3. Never put an API key directly in HTML/JS that ships to users.

## Setting up Google AdSense (real ads)
1. Apply for an AdSense account at https://www.google.com/adsense if you haven't already — you'll need a live, published website (see hosting steps below) for approval.
2. Once approved, get your **Publisher ID** (looks like `ca-pub-1234567890123456`) and create **ad units** to get **slot IDs**.
3. In `index.html`, find every instance of:
   - `ca-pub-XXXXXXXXXXXXXXXX` (5 places) → replace with your real publisher ID.
   - `0000000001`, `0000000002`, `0000000003`, `0000000004` → replace each with a real ad slot ID from your AdSense dashboard.
4. Ads will not display until: your AdSense account is approved, your real IDs are in place, and the site is live on a public HTTPS domain — ads never render on `file://` or during local testing.

## Adding real app icons (for "Add to Home Screen")
The manifest references `icon-192.png` and `icon-512.png`, which aren't included (they need to be actual image files). Create a simple square logo and export it at both sizes, save them in the same folder as `index.html`, and the app becomes installable on phones.

## Publishing / hosting options
This is a single self-contained static site (`index.html` + `manifest.json`). Pick whichever hosting fits how you want to use your Google account:

- **Google Sites**: create a site, embed the HTML via an "Embed code" block, or link to it if hosted elsewhere. Simplest but least control over the URL.
- **Firebase Hosting** (Google, free tier, real custom domain support):
  1. Install the Firebase CLI, run `firebase login`, then `firebase init hosting` inside this folder.
  2. Set the public directory to this folder, run `firebase deploy`.
  3. You get a live `https://your-project.web.app` URL — use this as the domain you submit to AdSense.
- **GitHub Pages** (free, works well with a Google account for sign-in): push this folder to a GitHub repo, enable Pages in repo settings, done.
- **Google Play / Android app**: a static HTML site can be wrapped as an installable Android app using a Trusted Web Activity (TWA) via Google's **Bubblewrap** tool, once it's hosted at a real HTTPS URL. That's a separate step after hosting — ask if you want a walkthrough.

## Notes
- All quiz/progress data is stored locally in each user's browser (`localStorage`) — it is not synced across devices or visible to you as the developer.
- If you want more courses, more quiz questions per topic, or a different visual theme, the `data` array near the top of the `<script>` tag in `index.html` is where all content lives — each course is one object with `name`, `topic`, `sub`, `notes`, and a `quiz` array.
